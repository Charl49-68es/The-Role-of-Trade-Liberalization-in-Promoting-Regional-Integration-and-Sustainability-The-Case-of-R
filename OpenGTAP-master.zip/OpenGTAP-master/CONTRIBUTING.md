# Contributing to OpenGTAP

First off, thanks for taking the time to contribute!

The following is a set of guidelines for contributing to OpenGTAP. These are mostly guidelines, not rules. Use your best judgment, and feel free to propose changes to this document in a pull request.

# How Can I Contribute?

Good question! We're currently working on guidelines and more information will be added as soon as it is available. 

If you would like to make a suggestion in the meantime, feel free to open an issue or email austin.drenski@gmail.com.

## Reporting Bugs

## Suggestions

### API Design

### Data File Formats

### Feature Requests

